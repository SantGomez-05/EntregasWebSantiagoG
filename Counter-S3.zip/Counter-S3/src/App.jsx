import React from "react"
import { HeaderComponent, BodyComponent, FooterComponent} from "./components"

export function App(){

    return (
<>

<HeaderComponent tittle='COUNTER'/>

<BodyComponent/>

<FooterComponent/>


</>
    )
}
