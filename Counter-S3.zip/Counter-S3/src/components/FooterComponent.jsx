import React from "react";
export function FooterComponent() {
    const footerStyle = {

        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: 'none',
        borderColor: 'none',
        height: '100px',
        width: '500px',
    }

    return(
        <footer style={footerStyle}>
            <h3>Santiago Gómez</h3>
        </footer>
    )
}