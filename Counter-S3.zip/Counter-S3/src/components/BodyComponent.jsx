import React, {useState} from 'react'
import {ButtonComponent, CounterComponent} from './index'
export function BodyComponent() {

    const [counter, setCounter] = useState(0)

    const add = () => {
        setCounter(counter + 1)
    }
    
    const substract = () => {
        setCounter(counter > 0 ?counter -1 : counter)
    }
    
    const mainStyle = {
        display: 'flex',
        justifyContent: 'center',
        justifyContent: 'space-between',
        alignItems: 'center',
        height: '140',
        backgroundColor: 'green',
        borderColor: 'white',
        width: '500px'
    }
    

    return (
        <>
            <main style={mainStyle}>
                <ButtonComponent action={substract} type='SUBSTRACT' label='-'/>
                

                <CounterComponent counterNum={counter}/>
                <ButtonComponent action={add} type='ADD' label='+'/>
            </main>
        </>
    )
    //<ButtonComponent onAdd={add} onReset={reset} onSubstract={substract}/>
}