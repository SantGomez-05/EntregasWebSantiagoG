import React from "react"
export function ButtonComponent({label, action}){


const dStyle = {
    display: 'flex',
    justifyContent: 'center',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'orange',
    fontSize: '3em'
}


    return(

    <div>
        <button style={dStyle} onClick={action}> { label } </button>
    </div>
    )
}
