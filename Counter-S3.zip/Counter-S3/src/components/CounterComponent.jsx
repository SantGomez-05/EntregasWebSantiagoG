import React from 'react'

export function CounterComponent ({counterNum}) {

    return(
        <>
        <h2>{counterNum}</h2>
        </>

    )
}
